package org.junit;

import java.util.ArrayList;
import java.util.UUID;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class BusOperator {
	private String name;
	private String address;
	private String baggage;
	private String mail;
	private String gender;
	private String tel;
	private Integer ticketNumber;
	private String travel;
	private String seats;
	private String seat;
	private String paymentInfo;
	private ArrayList people;
	

	UUID uniqueKey = UUID.randomUUID();

	/**
	 * Contructor BusOperator
	 */

	public BusOperator() {
		setPeople(new ArrayList());
	
	
	}
	
	final ImageIcon iconBus = new ImageIcon("C:\\Users\\mervebasar\\workspace\\FinalProject1\\bus.png");

	/**
	 * Adding a new person to arraylist.
	 */
	public void addPerson() {
		String travel = (String) JOptionPane.showInputDialog(null, "Please enter travel" , "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String name = (String) JOptionPane.showInputDialog(null, "Please enter name and surname of passanger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String address = (String) JOptionPane.showInputDialog(null, "Please enter related address of passenger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String baggage = (String) JOptionPane.showInputDialog(null, "Please enter baggage information of passenger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String gender = (String) JOptionPane.showInputDialog(null, "Please enter gender of passenger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String mail = (String) JOptionPane.showInputDialog(null, "Please enter email adress of passenger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String tel= (String) JOptionPane.showInputDialog(null, "Please enter phone number of passenger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		String paymentInfo=(String) JOptionPane.showInputDialog(null, "Payment information of passenger", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
		
		 final ImageIcon icon = new ImageIcon("C:\\Users\\mervebasar\\workspace\\FinalProject1\\seat.jpg");
			//JOptionPane.showMessageDialog(null, "", "BUS", JOptionPane.INFORMATION_MESSAGE, icon);
		    String[] choices = { "W01", "A02", "A03", "W04",
		    		             "W05", "A06", "A07", "W08",
		    		             "W09", "A10", "A11", "W12",
		    		             "W13", "A14", "A15", "W16",
		    		             "W17", "A18", "A19", "W20",
		    		             "W21", "A22", "A23", "W24",
		    		             "W25", "A26","A27", "A28", "W29"};
		    String seats = (String) JOptionPane.showInputDialog(null, "Choose now...",
		        "The Bus", JOptionPane.QUESTION_MESSAGE, icon, // Use
		                                                                        // default
		                                                                        // icon
		        choices, // Array of choices
		        choices[0]); // Initial choice
		    
		    JOptionPane.showMessageDialog(null, seats ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus);
		searchSeat(seats);
		
		/**
		 * Construct new person object.
		 */
		BusOperator person = new BusOperator(name, address, baggage, ticketNumber,gender,tel,mail,travel,paymentInfo, seats);
		

		/**
		 * adding Person object to arraylist.
		 * 
		 */
		
	   
	   getPeople().add(person);
		

		
		person.print();
	    
	}
	
				

	/**
	 * This method search person with specific name in the people arraylist.
	 * 
	 * @param name
	 *            Name of person search
	 */

	public void searchPerson(String uniqueKey) {

		for (int i = 0; i < getPeople().size(); i++) {
			BusOperator person = (BusOperator) getPeople().get(i);
			if (uniqueKey.equals(person.uniqueKey)) {
				person.print();
			}
		}
	}


		/**
	 * This method delete person saved by specific name in arraylist.
	 * 
	 * @param name
	 *            Name of person which will delete
	 */
	public void deletePerson(String uniqueKey) {

		for (int i = 0; i < getPeople().size(); i++) {
			BusOperator person = (BusOperator) getPeople().get(i);

			if (uniqueKey.equals(person.uniqueKey)) {
				getPeople().remove(i);
			}
		}
	}
	
	
	
	public void searchSeat(String seats) {

		for (int i = 0; i < getPeople().size(); i++) {
			BusOperator person = (BusOperator) getPeople().get(i);
			
			if (seats.equals(person.seats)) {
				 
				 JOptionPane.showMessageDialog(null, "THIS SEAT SELECTED FROM ANOTHER PASSENGER, SORRY!!", "Error", JOptionPane.ERROR_MESSAGE);
				 final ImageIcon icon = new ImageIcon("C:\\Users\\TOSHIBA\\workspace\\FinalProject\\seat.jpg");		 
				    String[] choices = { "A02", "A03", "W04",
	    		             "W05", "A06", "A07", "W08",
	    		             "W09", "A10", "A11", "W12",
	    		             "W13", "A14", "A15", "W16",
	    		             "W17", "A18", "A19", "W20",
	    		             "W21", "A22", "A23", "W24",
	    		             "W25", "A26","A27", "A28", "W29"};
				    String seat = (String) JOptionPane.showInputDialog(null, "Choose now...",
				        "The Bus", JOptionPane.QUESTION_MESSAGE, icon, // Use icon
				                                                                      
				        choices, // Array of choices
				        choices[0]); // Initial choice
				    JOptionPane.showMessageDialog(null, seat  ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus);
				    
				    deletePerson(person.name);			
				 	 
			}else{
				
				JOptionPane.showMessageDialog(null, "Passanger has been added.");
			
			}
			}
		}



	/**
	 * This constructs with a specified name,last name and email.
	 * 
	 * @param name
	 *            Name of person
	 * @param address
	 *            Address of person
	 * @param idNum
	 *            Id Number of person
	 */
	public BusOperator(String name, String address, String baggage, Integer uniqueKey, String gender, String tel, String mail, String travel,String paymentInfo,String seats) {
		this.name = name;
		this.address = address;
		this.baggage = baggage;
		ticketNumber = uniqueKey;
		this.gender=gender;
		this.tel=tel;
		this.mail=mail;
		this.travel=travel;
		this.seats=seats;
		this.paymentInfo=paymentInfo;
	}
	

	

	public void print() {
		JOptionPane.showMessageDialog(null,
				"Name: " + name + "\nAddress: " + address + "\nGender: " + gender + "\nEmail: " + mail 
				+ "\nPhone Number: " +tel +"\nBaggage: " + baggage + "\nTicketID: " + uniqueKey  + "\nTravel: " + travel+   "\nPayment Information: " + paymentInfo 
				);

	}

	public ArrayList<BusOperator> checkPerson(){
		return getPeople();
	}



	public ArrayList<BusOperator> getPeople() {
		return getPeople();
	}



	public void setPeople(ArrayList people) {
		this.people = people;
	}
}
