
import java.util.UUID;

import javax.swing.*;

public class Test {
	
	
	
	
	public static void main(String args[]) {
		BusOperator address = new BusOperator();
		String input, input1 = null;
		int value;
		/*
		 * UUID is the fastest and easiest way to generate unique ID in Java.
		 * uuids and guids are created from 128 bit integers and randomly
		 * created 128 bit integer. The possibility that randomly created seat in each travel
		 * with 128 bit number is nearly impossible in mathematically.
		 */

		UUID uniqueKey = UUID.randomUUID();
		
		final ImageIcon iconBus = new ImageIcon("C:\\Users\\useruser\\workspace\\FinalProject\\bus.png");
		
		JOptionPane.showMessageDialog(null, " WELCOME TO BUS OPERATOR "
				
                ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus
				
				);
		
		
		JOptionPane.showMessageDialog(null, " Travel of Istanbul \n  \n Istanbul-Izmır Travel \n "
				+ "Time: 12:30 \n "
				+ "Date: 31.12.2016 \n"
				+ "Route Istanbul-Izmır \n"
				+ "Price: 80TL \n\n"
				
				
                ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus
				
				);
		

		
		


		while (true) {
			input = (String) JOptionPane.showInputDialog(null,
					"Please choose the operation  \n 1 Create Reservation \n 2 Search Reservation\n 3 Cancel Reservation \n 4 Change Reservation"
					, "BUS", JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
			value = Integer.parseInt(input);
			/**
			 * switch case with option pane.
			 */
			switch (value) {
			case 1:

				address.addPerson();
				
				JOptionPane.showMessageDialog(null, "Email and SMS are sent for travel information."  ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus);
				
				
				break;
			case 2:
				input1 = (String) JOptionPane.showInputDialog(null,
						"Please enter passenger id to search "
						, "BUS", JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
				
				address.searchPerson(input1);
				break;
			// If you delete or write wrong person which is you search system
			// directly return to Dialog choose pane.
			case 3:
				input1 =(String) JOptionPane.showInputDialog(null,"Please enter id of passanger to delete ", "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
				address.deletePerson(input1);
				JOptionPane.showMessageDialog(null, "Person has been deleted."  ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus);
				break;
			case 4:
				input1 =(String) JOptionPane.showInputDialog(null,"Please enter passsenger id to modify " , "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus,null,"");
				address.deletePerson(input1);
				JOptionPane.showMessageDialog(null, "For modifying please enter all infos about the passenger"  ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus);
				address.addPerson();
				JOptionPane.showMessageDialog(null, "Passenger informations has been modified."  ,  "BUS",JOptionPane.INFORMATION_MESSAGE, iconBus);
			}
		}
	}
}