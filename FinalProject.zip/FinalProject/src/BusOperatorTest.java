import java.util.ArrayList;

import org.junit.Test;


public class BusOperatorTest {


	public void testDeletePerson() {
		//fail("Not yet implemented");
		BusOperator person = new BusOperator();
		person.deletePerson("13231ads24324-123231-213");
		ArrayList<BusOperator> actual = person.checkPerson();
		String expected = "";
		assertEquals(actual, expected);
	}
	
	private void assertEquals(ArrayList<BusOperator> actual, String expected) {
		// TODO Auto-generated method stub
		
	}


	public void testSearchPerson() {
		//fail("Not yet implemented");
		BusOperator person = new BusOperator();
		person.searchPerson("13231ads24324-123231-213");
		ArrayList<BusOperator> actual = person.checkPerson();
		String expected = "13231ads24324-123231-213";
		assertEquals(actual, expected);
	}


	public void testPrint() {
		//fail("Not yet implemented");
		BusOperator person = new BusOperator();
		String actual = person.toString();
		String expected = "";
		assertEquals(actual, expected);
	}

	private void assertEquals(String actual, String expected) {
		// TODO Auto-generated method stub
		
	}

	

}	
